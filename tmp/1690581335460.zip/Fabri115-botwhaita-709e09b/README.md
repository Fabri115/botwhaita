[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
 
  <p align="center">
    
[![Typing SVG](https://readme-typing-svg.herokuapp.com?font=Fira+Code&weight=900&size=35&pause=1000&center=true&width=435&lines=%E2%98%81%EF%B8%8F%F0%9D%91%B4%F0%9D%92%90%F0%9D%92%90%F0%9D%92%8F%F0%9D%91%AA%F0%9D%92%8D%F0%9D%92%90%F0%9D%92%96%F0%9D%92%85%F0%9D%92%94%E2%87%9D%F0%9D%90%81%E1%8F%AB%F0%9D%90%93%E2%98%81%EF%B8%8F)](https://git.io/typing-svg)  


  <p align="center">
<a href="https://github.com/Fabri115/followers"><img title="Followers" src="https://img.shields.io/github/followers/Fabri115?color=red&style=flat-square"></a>
<a href="https://github.com/Fabri115/Fabri115/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/Fabri115?color=blue&style=flat-square"></a>
<a href="https://github.com/Fabri115/network/members"><img title="Forks" src="https://img.shields.io/github/forks/Fabri115/botwhaita?color=red&style=flat-square"></a>
<a href="https://komarev.com/ghpvc/?username=Fabri115&color=blue&style=flat-square&label=Profile+Visual"><img src="https://komarev.com/ghpvc/?username=Fabri115&color=blue&style=flat-square&label=Profile+Visual" />
<a href="https://github.com/Fabri115/Fabri115/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/Fabri115/botwhaita?label=Watcher'srepo&color=blue&style=flat-square"></a>
<a href="https://github.com/Fabri115/botwhaita"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/Fabri115/AyGemuy/"><img title="Size" src="https://img.shields.io/github/repo-size/Fabri115/botwhaita?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FFabri115%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false"/></a>
<a href="https://github.com/Fabri115/botwhaita/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a
<img width="" src="https://img.shields.io/github/repo-size/fabri115/botwhaita?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
<p align="center">
<a href="https://wa.me/393518398856" target="_blank"><img src="https://img.shields.io/badge/Whatsapp-%808080.svg?&style=flat-square&logo=Whatsapp&logoColor=white" alt="WhatsApp"></a>
<a href="https://github.com/Fabri115"><img src="https://img.shields.io/badge/-GitHub-black?style=flat-square&logo=github"></a>
<a href="https://chat.whatsapp.com/DrnPDROIs6W8ZGCLPvKL0t" target="_blank"><img src="https://img.shields.io/badge/Grupo-%808080.svg?&style=flat-square&logo=whatsapp&logoColor=white" alt="Whatsapp"></a>


<p align="center">
    <img src="https://img.shields.io/badge/OS-Windows-blue?&logo=Windows" />
    <img alt="JavaScript" src="https://img.shields.io/badge/javascript%20-%23323330.svg?&style=for-the-badge&logo=javascript&logoColor=%23F7DF1E"/>
    <img src="https://img.shields.io/badge/Text%20Editor-Visual%20Studio%20Code-blue?&logo=visual%20studio%20code&logoColor=blue" />
<p align="center">
<a href="https://www.buymeacoffee.com/Fabri115"><img src="https://img.buymeacoffee.com/button-api/?text=Buy me a candy&emoji=🍬&slug=Fabri115&button_colour=FFDD00&font_colour=000000&font_family=Lato&outline_colour=000000&coffee_colour=ffffff" /></a>



[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

<h1 align="center"> 
  `⚙️ CLICK THE PHOTO TO WATCH THE VIDEO TUTORIAL 𝑴☁️⚙️`
<h1 align="center">
<a href="https://youtu.be/6Cg1yUMz-Do"><img src= "https://i.imgur.com/BqCg8Ao.png" alt="BOT" width="720">
</p>

[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)


### `—◉ ⚙️ CONFIGURAZIONE 𝑴☁️ ⚙️`

`USA IL BOTTONE PER ESEGUIRE IL FORK`
  
  <a href="https://github.com/Fabri115/BotWhaIta/fork"><img title="bot" src="https://github.com/Alien-alfa/Alien-alfa/blob/beta/img/pngegg.png?raw=true" width="200"></a>
<br>
- CLONARE LA REPOSITORY [qui](https://github.com/Fabri115/BotWhaIta/fork)
- CAMBIARE NUMERO DEL PROPRIETARIO [qui](https://github.com/Fabri115/BotWhaIta/blob/master/config.js)
 
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

  
### `—◉ 💥 ATTIVA SU KOYEB 💥`

[![Attiva su Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/Fabri115/BotWhaIta&branch=master&name=mysticbot)

[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
  
### `—◉ 🌌 ATTIVA 𝑴☁️ SU REPLIT 🌌`

[![Run on Repl.it](https://replit.com/badge/github/Fabri115/botwhaita)](https://replit.com/new/github/Fabri115/botwhaita)

[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
 
### `—◉ 🌌 ATTIVA 𝑴☁️ SU HEROKU 🌌`
  
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Fabri115/botwhaita)

[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `—◉ VERSIONE DI TERMUX NECESSARIA: ` 
https://www.mediafire.com/file/0npdmv51pnttps0/com.termux_0.119.1-119_minAPI21(arm64-v8a,armeabi-v7a,x86,x86_64)(nodpi)_apkmirror.com.apk/file

[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `—◉ 👾 ATTIVA TERMUX 👾` 

Comandi termux di base, necessari per l'avvio del bot:

-_1 COMANDO :

termux-change-repo

Conferma, segna la terza casella e conferma e continua >

-_2 COMANDO :

apt-get upgrade

Dovrai digitare y e confermare ogni volta che lo chiedi.

-_3 COMANDO :

apt-get update

Dovrai digitare y e confermare ogni volta che lo chiedi.

-_4 Comando :

pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install git -y

-_5 COMANDO :

termux-setup-storage

e conferma.

----_-
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)


### `—◉ ⇝ ATTIVA 𝑴☁️. COMANDO PER INSTALLARE LA CARTELLA DI 𝑴☁️BOT 🌌`
```bash
cd /sdcard && rm -rf BotWhaIta && git clone https://github.com/Fabri115/BotWhaIta.git && cd BotWhaIta && sh start.sh 
```
COPIALO TUTTO E INCOLLALO SU TERMUX, NON COPIARE MEZZA O UNA COSA, E' TUTTO INSIEME

### `—◉ 👾 ATTIVA 𝑴☁️ IN TERMUX 👾` 
- DIGITA QUESTI COMANDI:
```bash
termux-setup-storage
```

```bash
pkg upgrade -y && pkg update -y
```

```bash
pkg install git -y
```
  
```bash
pkg install nodejs -y  
```
  
```bash
pkg install ffmpeg -y
```  
  
```bash
pkg install imagemagick -y
``` 

```bash
pkg install yarn
```    

```bash
git clone https://github.com/Fabri115/botwhaita.git
```
  
```bash
cd botwhaita
```  

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `—◉ ✔️ AVVIA 𝑴☁️ IN TERMUX ✔️`

DIGITA QUESTI COMANDI:
```bash
> cd 
```
```bash
> cd BotWhaIta
```
```bash
> npm start
```
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)
  
### `—◉ ✔️ For 24/7 Activation 𝑴☁️ TERMUX ✔️`
  
 ```bash
> npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
  ```
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `—◉ 👽 OTTIENI UN ALTRO CODICE QR 𝑴☁️ 👽`

DIGITA QUESTI COMANDI:
```bash
> cd 
```
```bash
> cd BotWhaIta
```
```bash
> rm -rf BotWhaItaSession
```
```bash
> npm start
```
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `FOR WINDOWS/VPS/RDP USER`

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/Fabri115/BotWhaIta
```
```bash
cd BotWhaIta
```
```bash
npm install
```
```bash
npm update
```

---------

### `Run`

```bash
node .
```
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

---------
### `—◉ 👽 OTTIENI UN ALTRO CODICE QR 𝑴☁️ 👽`

DIGITA QUESTI COMANDI:
```bash
> cd 
```
```bash
> cd BotWhaIta
```
```bash
> rm BotWhaItaSession
```
```bash
> npm start
```
---------
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `—◉ 📝 NOTE 𝑴☁️ 📝`
- IL BOT 𝑴☁️ E' COMPATIBILE CON WHATSAPP BUSINESS E WHATSAPP NORMALE
- PER BLOCCARE GLI UTENTI IN PRIVATO ESEGUI IL COMANDO .attiva antiprivato
- SE DOVESSI VEDERE I MSG DEL BOT 'IN ATTESA' ELIMINA LA CARTELLA 'MYSTICSESSION' DA BOT ATTIVO
---------
[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)


### `—◉ ⚠️ MOD & DEVELOPER 𝑴☁️ ⚠️ `

  
| [![Fabri115](https://github.com/Fabri115.png?size=200)](https://github.com/Fabri115) |
|----|
|   <div align="center">[꧁𓊈𒆜SUPER FABRI𒆜𓊉꧂](https://github.com/Fabri115) |
|  𒆜Bug report,updates, news, 𒆜 |></a>

```SE MI VUOI BENE, DONA PER FARMI COMPRARE LE API KEYS VIP ```
[`paypal > fabri115` > `https://www.paypal.me/Fabri115i`](https://www.paypal.com/donate?campaign_id=KTBZ6VBY927VA&v=1&utm_source=unp&utm_medium=email&utm_campaign=RT001640&utm_unptid=23c96436-0a01-11ee-8170-3cfdfeec12a8&ppid=RT001640&cnac=IT&rsta=it_IT%28it-IT%29&cust=3ZENKTZ28SZAE&unptid=23c96436-0a01-11ee-8170-3cfdfeec12a8&calc=f7960484092de&unp_tpcid=donate-button-campaign-created&page=main%3Aemail%3ART001640&pgrp=main%3Aemail&e=cl&mchn=em&s=ci&mail=sys&appVersion=1.177.0&xt=104038%2C127632)

[![-----------------------------------------------------](https://raw.githubusercontent.com/andreasbm/readme/master/assets/lines/colored.png)](#table-of-contents)

### `—◉ ⚠️ CONTRIBUTORS 𝑴☁️ ⚠️ `

| [![MoonContentCreator](https://github.com/MoonContentCreator.png?size=200)](https://github.com/MoonContentCreator) |
|----|
|   <div align="center">  [꧁𓊈𒆜   DANIEL 𝐁𝐢𝐱𝐛𝐲🔮  𒆜𓊉꧂](https://github.com/MoonContentCreator) |
|  𒆜Thanks to Creator of BixbyBot-Md |

| [![BrunoSobrino](https://github.com/BrunoSobrino.png?size=200)](https://github.com/BrunoSobrino) |
|----|
|   [꧁𓊈𒆜   BrunoSobrino  𒆜𓊉꧂](https://github.com/BrunoSobrino) |
|  𒆜Thanks to Creator of TheMystic-Bot-MD | 
  </div>
