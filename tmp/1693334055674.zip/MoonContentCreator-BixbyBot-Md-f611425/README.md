[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&size=33&pause=1000&width=435&lines=Bixby+Bot+Ediz+by+Dan;thanks+to+%40Fabri115)](https://git.io/typing-svg)


  <p align="center">
<a href="https://github.com/MoonContentCreator/followers"><img title="Followers" src="https://img.shields.io/github/followers/MoonContentCreator?color=red&style=flat-square"></a>
<a href="https://github.com/MoonContentCreator/MoonContentCreator/stargazers/"><img title="Stars" src="https://img.shields.io/github/stars/MoonContentCreator?color=blue&style=flat-square"></a>
<a href="https://github.com/MoonContentCreator/network/members"><img title="Forks" src="https://img.shields.io/github/forks/MoonContentCreator/BixbyBot-Md?color=red&style=flat-square"></a>
<a href="https://komarev.com/ghpvc/?username=Fabri115&color=blue&style=flat-square&label=Profile+Visual"><img src="https://komarev.com/ghpvc/?username=MoonContentCreator&color=blue&style=flat-square&label=Profile+Visual" />
<a href="https://github.com/MoonContentCreator/MoonContentCreator/watchers"><img title="Watching" src="https://img.shields.io/github/watchers/MoonContentCreator/BixbyBot-Md?label=Watcher'srepo&color=blue&style=flat-square"></a>
<a href="https://github.com/MoonContentCreator/BixbyBot-Md"><img title="Open Source" src="https://badges.frapsoft.com/os/v2/open-source.svg?v=103"></a>
<a href="https://github.com/MoonContentCreator/AyGemuy/"><img title="Size" src="https://img.shields.io/github/repo-size/MoonContentCreator/BixbyBot-Md?style=flat-square&color=green"></a>
<a href="https://hits.seeyoufarm.com"><img src="https://hits.seeyoufarm.com/api/count/incr/badge.svg?url=https%3A%2F%2Fgithub.com%2FMoonContentCreator%2Fhit-counter&count_bg=%2379C83D&title_bg=%23555555&icon=&icon_color=%23E7E7E7&title=hits&edge_flat=false"/></a>
<a href="https://github.com/MoonContentCreator/BixbyBot-Md/graphs/commit-activity"><img height="20" src="https://img.shields.io/badge/Maintained%3F-yes-green.svg"></a
<img width="" src="https://img.shields.io/github/repo-size/MoonContentCreator/BixbyBot-Md?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
<p align="center">
<a href="https://wa.me/3903717177117?text=Ciao👋" target="_blank"><img src="https://img.shields.io/badge/Contattami-%808080.svg?&style=flat-square&logo=Whatsapp&logoColor=white" alt="WhatsApp"></a>
<a href="https://chat.whatsapp.com/InZqSk4lsyzKJUtSWfsdjF" target="_blank"><img src="https://img.shields.io/badge/MoonClouds-%808080.svg?&style=flat-square&logo=whatsapp&logoColor=white" alt="Whatsapp"></a>
<a href="https://chat.whatsapp.com/DrnPDROIs6W8ZGCLPvKL0t" target="_blank"><img src="https://img.shields.io/badge/Gruppo Bot-%808080.svg?&style=flat-square&logo=whatsapp&logoColor=white" alt="Whatsapp"></a>
<a href="https://wa.me/393716229204?text=.menu" target="_blank"><img src="https://img.shields.io/badge/BixbyBot-official-%808080.svg?&style=flat-square&logo=Whatsapp&logoColor=white" alt="WhatsApp"></a>


 <p align="center">
<img width="" src="https://telegra.ph/file/ff78ecea9433a2e2044f6.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>
<p align="center">
<img width="" src="https://telegra.ph/file/339b23425fb26bb2728b7.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>


### ` 𝐀𝐍𝐓𝐄𝐏𝐑𝐈𝐌𝐀 𝐃𝐄𝐋 𝐌𝐄𝐍𝐔 👆`
---------
<p align="center">
<img width="" src="https://telegra.ph/file/99a2bce77c1661797c610.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐕𝐄𝐑𝐘 𝐅𝐀𝐒𝐓 𝐏𝐈𝐍𝐆 ⚡`
𝐔𝐧𝐨 𝐝𝐞𝐢 𝐛𝐨𝐭 𝐩𝐢𝐮' 𝐯𝐞𝐥𝐨𝐜𝐢 𝐞 𝐚𝐟𝐟𝐢𝐝𝐚𝐛𝐢𝐥𝐢 𝐢𝐧 𝐜𝐢𝐫𝐜𝐨𝐥𝐚𝐳𝐢𝐨𝐧𝐞 𝐬𝐮 𝐖𝐡𝐚𝐭𝐬𝐀𝐩𝐩 🇮🇹
---------
<p align="center">
<img width="" src="https://telegra.ph/file/2235db8a736b318be014f.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>
<p align="center">
<img width="" src="https://telegra.ph/file/5e3d257ddecb3642b378f.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>
<p align="center">
<img width="" src="https://telegra.ph/file/2247ad9f774cba7907ece.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐌𝐔𝐓𝐀/𝐒𝐌𝐔𝐓𝐀, 𝐖𝐀𝐑𝐍/𝐔𝐍𝐖𝐀𝐑𝐍 𝐄 𝐌𝐒𝐆`

𝐃𝐢𝐫𝐞𝐭𝐭𝐚𝐦𝐞𝐧𝐭𝐞 𝐝𝐚 𝐓𝐞𝐥𝐞𝐠𝐫𝐚𝐦 𝐚𝐫𝐫𝐢𝐯𝐚𝐧𝐨 𝐬𝐮 𝐰𝐡𝐚𝐭𝐬𝐚𝐩𝐩 𝐦𝐮𝐭𝐚 𝐞 𝐬𝐦𝐮𝐭𝐚 𝐜𝐨𝐧 𝐩𝐨𝐬𝐬𝐢𝐛𝐢𝐥𝐢𝐭𝐚' 𝐝𝐢 𝐭𝐞𝐧𝐞𝐫 𝐜𝐨𝐧𝐭𝐨 𝐝𝐞𝐥𝐥' 𝐚𝐭𝐭𝐢𝐯𝐢𝐭𝐚' 𝐝𝐞𝐥𝐥'𝐮𝐭𝐞𝐧𝐭𝐞 𝐜𝐨𝐧 𝐥𝐞 𝐯𝐚𝐫𝐢𝐞 𝐚𝐦𝐦𝐨𝐧𝐢𝐳𝐢𝐨𝐧𝐢, 𝐝𝐨𝐩𝐨 𝟑 𝐚𝐦𝐦𝐨𝐧𝐢𝐳𝐢𝐨𝐧𝐢 (𝐰𝐚𝐫𝐧) 𝐥'𝐮𝐭𝐞𝐧𝐭𝐞 𝐯𝐞𝐫𝐫𝐚' 𝐫𝐢𝐦𝐨𝐬𝐬𝐨 𝐝𝐚𝐥 𝐠𝐫𝐮𝐩𝐩𝐨
---------
<p align="center">
<img width="" src="https://telegra.ph/file/ef5e1f14a4deea385b37f.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐁𝐎𝐓 𝐌𝐔𝐋𝐓𝐈-𝐅𝐔𝐍𝐙𝐈𝐎𝐍𝐈 ⚙️`
---------
<p align="center">
<img width="" src="https://telegra.ph/file/37bdbaff25c35002defe8.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>
<p align="center">
<img width="" src="https://telegra.ph/file/ed4ee63ed7162686fd63e.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>
<p align="center">
<img width="" src="https://telegra.ph/file/aa4a6f4c56d18b6710f26.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐀𝐍𝐓𝐈𝐓𝐈𝐊𝐓𝐎𝐊, 𝐀𝐍𝐓𝐈𝐈𝐍𝐒𝐓𝐀, 𝐀𝐍𝐓𝐈𝐋𝐈𝐍𝐊 𝐄 𝐌𝐎𝐋𝐓𝐎 𝐀𝐋𝐓𝐑𝐎...`
---------
<p align="center">
<img width="" src="https://telegra.ph/file/f999785f9b4e0e57b6ce4.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐒𝐓𝐀𝐓𝐎`
𝐓𝐢𝐞𝐧𝐢 𝐜𝐨𝐧𝐭𝐨 𝐝𝐞𝐥𝐥𝐞 𝐟𝐮𝐧𝐳𝐢𝐨𝐧𝐚𝐥𝐢𝐭𝐚' 𝐚𝐭𝐭𝐢𝐯𝐞 𝐞 𝐝𝐢 𝐪𝐮𝐞𝐥𝐥𝐞 𝐝𝐢𝐬𝐚𝐭𝐭𝐢𝐯𝐚𝐭𝐞
---------
<p align="center">
<img width="" src="https://telegra.ph/file/8ee273c03c89468d52ba2.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐈𝐍𝐅𝐎𝐒𝐓𝐀𝐓𝐎`
𝐃𝐞𝐬𝐜𝐫𝐢𝐳𝐢𝐨𝐧𝐞 𝐝𝐞𝐭𝐭𝐚𝐠𝐥𝐢𝐚𝐭𝐚 𝐝𝐞𝐥𝐥𝐞 𝐟𝐮𝐧𝐳𝐢𝐨𝐧𝐚𝐥𝐢𝐭𝐚'
---------
<p align="center">
<img width="" src="https://telegra.ph/file/e5fe622f276ceba6001ab.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐆𝐑𝐔𝐏𝐏𝐎`
𝐒𝐜𝐨𝐩𝐫𝐢 𝐜𝐨𝐦𝐚𝐧𝐝𝐢, 𝐠𝐢𝐨𝐜𝐡𝐢 𝐞 𝐭𝐚𝐧𝐭𝐨 𝐚𝐥𝐭𝐫𝐨 𝐧𝐞𝐢 𝐯𝐚𝐫𝐢 𝐦𝐞𝐧𝐮' 𝐝𝐞𝐥 𝐛𝐨𝐭
---------
<p align="center">
<img width="" src="https://telegra.ph/file/a2499ca2d3a286718581f.jpg?color=red&label=Repo%20Size&style=for-the-badge&logo=appveyor">
</p>

### `𝐅𝐈𝐗 𝐌𝐄𝐒𝐒𝐀𝐆𝐆𝐈 𝐈𝐍 𝐀𝐓𝐓𝐄𝐒𝐀...`
---------
### `✧ 𝐂𝐎𝐍𝐅𝐈𝐆𝐔𝐑𝐀𝐙𝐈𝐎𝐍𝐄 𝐁𝐢𝐱𝐛𝐲🔮 `

`𝐔𝐒𝐀 𝐈𝐋 𝐁𝐎𝐓𝐓𝐎𝐍𝐄 𝐏𝐄𝐑 𝐄𝐒𝐄𝐆𝐔𝐈𝐑𝐄 𝐈𝐋 𝐅𝐎𝐑𝐊`
  
  <a href="https://github.com/MoonContentCreator/BixbyBot-Md/fork"><img title="bot" src="https://github.com/Alien-alfa/Alien-alfa/blob/beta/img/pngegg.png?raw=true" width="200"></a>
<br>
- 𝐂𝐋𝐎𝐍𝐀𝐑𝐄 𝐋𝐀 𝐑𝐄𝐏𝐎𝐒𝐈𝐓𝐎𝐑𝐘 [qui](https://github.com/MoonContentCreator/BixbyBot-Md/fork)
- 𝐂𝐀𝐌𝐁𝐈𝐀𝐑𝐄 𝐍𝐔𝐌𝐄𝐑𝐎 𝐃𝐄𝐋 𝐏𝐑𝐎𝐏𝐑𝐈𝐄𝐓𝐀𝐑𝐈𝐎 [qui](https://github.com/MoonContentCreator/BixbyBot-Md/blob/master/config.js)
 
 
  
### `✧ 𝐀𝐓𝐓𝐈𝐕𝐀 𝐒𝐔 𝐊𝐎𝐘𝐄𝐁`

[![Attiva su Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=github.com/MoonContentCreator/BixbyBot-Md&branch=master&name=mysticbot)
  
### `✧ 𝐀𝐓𝐓𝐈𝐕𝐀 𝐁𝐢𝐱𝐛𝐲🔮 𝐒𝐔 𝐑𝐄𝐏𝐋𝐈𝐓`

[![Run on Repl.it](https://replit.com/badge/github/MoonContentCreator/BixbyBot-Md)](https://replit.com/new/github/MoonContentCreator/BixbyBot-Md)

 
### `✧ 𝐀𝐓𝐓𝐈𝐕𝐀 𝐁𝐢𝐱𝐛𝐲🔮 𝐒𝐔 𝐇𝐄𝐑𝐎𝐊𝐔 `
  
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/MoonContentCreator/BixbyBot-Md)

### `✧ 𝐕𝐄𝐑𝐒𝐈𝐎𝐍𝐄 𝐃𝐈 𝐓𝐄𝐑𝐌𝐔𝐗 𝐍𝐄𝐂𝐄𝐒𝐒𝐀𝐑𝐈𝐀: ` 
https://www.mediafire.com/file/0npdmv51pnttps0/com.termux_0.119.1-119_minAPI21(arm64-v8a,armeabi-v7a,x86,x86_64)(nodpi)_apkmirror.com.apk/file

### `✧ 𝐀𝐓𝐓𝐈𝐕𝐀 𝐓𝐄𝐑𝐌𝐔𝐗 ` 

Comandi termux di base, necessari per l'avvio del bot:

-_1 COMANDO :

termux-change-repo

Conferma, segna la terza casella e conferma e continua >

-_2 COMANDO :

apt-get upgrade

Dovrai digitare y e confermare ogni volta che lo chiedi.

-_3 COMANDO :

apt-get update

Dovrai digitare y e confermare ogni volta che lo chiedi.

-_4 Comando :

pkg upgrade -y && pkg update -y && pkg install nodejs -y && pkg install nodejs-lts -y && pkg install ffmpeg -y && pkg install wget -y && pkg install git -y

-_5 COMANDO :

termux-setup-storage

e conferma.

----_-


### `✧ 𝐂𝐎𝐌𝐀𝐍𝐃𝐎 𝐏𝐄𝐑 𝐈𝐍𝐒𝐓𝐀𝐋𝐋𝐀𝐑𝐄 𝐋𝐀 𝐂𝐀𝐑𝐓𝐄𝐋𝐋𝐀 𝐃𝐈 𝐁𝐢𝐱𝐛𝐲🔮`
```bash
cd /sdcard && rm -rf BixbyBot && git clone https://github.com/MoonContentCreator/BixbyBot-Md.git && cd BixbyBot-Md && sh start.sh 
```
COPIALO TUTTO E INCOLLALO SU TERMUX, NON COPIARE MEZZA O UNA COSA, E' TUTTO INSIEME

### `✧ 𝐀𝐓𝐓𝐈𝐕𝐀 𝐁𝐢𝐱𝐛𝐲🔮 𝐈𝐍 𝐓𝐄𝐑𝐌𝐔𝐗 ` 
- 𝐃𝐈𝐆𝐈𝐓𝐀 𝐐𝐔𝐄𝐒𝐓𝐈 𝐂𝐎𝐌𝐀𝐍𝐃𝐈:
```bash
termux-setup-storage
```

```bash
pkg upgrade -y && pkg update -y
```

```bash
pkg install git -y
```
  
```bash
pkg install nodejs -y  
```
  
```bash
pkg install ffmpeg -y
```  
  
```bash
pkg install imagemagick -y
``` 

```bash
pkg install yarn
```    

```bash
cd /sdcard && rm -rf BixbyBot && git clone https://github.com/MoonContentCreator/BixbyBot-Md.git
```
  
```bash
cd BixbyBot-Md
```  

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
sh start.sh
```

### `✧ 𝐀𝐕𝐕𝐈𝐀 𝐁𝐢𝐱𝐛𝐲🔮 𝐈𝐍 𝐓𝐄𝐑𝐌𝐔𝐗`

DIGITA QUESTI COMANDI:
```bash
> cd 
```
```bash
> cd BixbyBot-Md
```
```bash
> sh start.sh
```
  
### `𝐁𝐢𝐱𝐛𝐲🔮 𝟐𝟒/𝟕 𝐀𝐜𝐭𝐢𝐯𝐚𝐭𝐢𝐨𝐧 𝐓𝐄𝐑𝐌𝐔𝐗`
  
 ```bash
> npm i -g pm2 && pm2 start index.js && pm2 save && pm2 logs
  ```

### `✧ 𝐎𝐓𝐓𝐈𝐄𝐍𝐈 𝐔𝐍 𝐀𝐋𝐓𝐑𝐎 𝐂𝐎𝐃𝐈𝐂𝐄 𝐐𝐑 𝐁𝐢𝐱𝐛𝐲🔮 `

DIGITA QUESTI COMANDI:
```bash
> cd 
```
```bash
> cd BixbyBot-Md
```
```bash
> rm -rf MysticSession
```
```bash
> sh start.sh
```

### `𝐅𝐎𝐑 𝐖𝐈𝐍𝐃𝐎𝐖𝐒/𝐕𝐏𝐒/𝐑𝐃𝐏 𝐔𝐒𝐄𝐑`

* Download And Install Git [`Click Here`](https://git-scm.com/downloads)
* Download And Install NodeJS [`Click Here`](https://nodejs.org/en/download)
* Download And Install FFmpeg [`Click Here`](https://ffmpeg.org/download.html) (**Don't Forget Add FFmpeg to PATH enviroment variables**)
* Download And Install ImageMagick [`Click Here`](https://imagemagick.org/script/download.php)

```bash
git clone https://github.com/MoonContentCreator/BixbyBot-Md
```
```bash
cd BixbyBot-Md
```
```bash
npm install
```
```bash
npm update
```

---------

### `Run`

```bash
node .
```

---------
### `✧ 𝐎𝐓𝐓𝐈𝐄𝐍𝐈 𝐔𝐍 𝐀𝐋𝐓𝐑𝐎 𝐂𝐎𝐃𝐈𝐂𝐄 𝐐𝐑 𝐁𝐢𝐱𝐛𝐲🔮 `

DIGITA QUESTI COMANDI:
```bash
> cd 
```
```bash
> cd BixbyBot-Md
```
```bash
> rm MysticSession
```
```bash
> sh start.sh
```
---------
### `✧ 📝 𝐍𝐎𝐓𝐄 𝐁𝐢𝐱𝐛𝐲🔮 📝`
- IL BOT 𝐁𝐢𝐱𝐛𝐲🔮 E' COMPATIBILE CON WHATSAPP BUSINESS E WHATSAPP NORMALE
- PER BLOCCARE GLI UTENTI IN PRIVATO ESEGUI IL COMANDO .attiva antiprivato
- SE I MESSAGGI DEL BOT RISULTANO IN "ATTESA" ESEGUI IL COMANDO .ds E ATTENDI QUALCHE ISTANTE
---------
## `✧ 𝐌𝐎𝐃𝐃𝐄𝐑 𝐄 𝐂𝐎𝐋𝐋𝐀𝐁𝐎𝐑𝐀𝐓𝐎𝐑𝐈 ` 
<div><button id="boton" type="button">BotWhaIta - By Fabri115</button></div> 
 <a href="https://github.com/Fabri115/BotWhaIta.git"><img src="https://github.com/fabri115.png" width="150" height="150" alt="adiwajshing"/></a>

## `✧ 𝐂𝐑𝐄𝐃𝐈𝐓𝐈 𝐄 𝐁𝐀𝐒𝐄 𝐃𝐄𝐋 𝐁𝐎𝐓` 
<a href="https://github.com/BrunoSobrino/TheMystic-Bot-MD"><img src="https://github.com/brunosobrino.png" width="150" height="150" alt="adiwajshing"/></a>
<div><button id="boton" type="button">TheMystic-Bot-MD - By BrunoSobrino</button></div> 
