
const handler = async (m, {conn, usedPrefix}) => {
  const botol = global.wm;

  m.reply(`
 ✧──[ *Gruppo Ufficiale* ]──✧
┈┈┈┈┈┈┈┈┈┈┈┈
*𝑴𝒐𝒐𝒏𝑪𝒍𝒐𝒖𝒅𝒔⇝ ꪶ͢𝑴☁️ꫂ ᵉᵈᶦᶻ ²⁰²³*
⟿ https://chat.whatsapp.com/JgshFc8KChtAai6ZfbI9QZ
┈┈┈┈┈┈┈┈┈┈┈┈
✧─[ *𝐌𝐨𝐨𝐧 𝐏𝐚𝐜𝐤⇝ ꪶ͢𝑴☁️* ]─✧
┈┈┈┈┈┈┈┈┈┈┈┈
*💠⃟⛩️ ETERNALS 💠⃟⛩️*
⟿ https://chat.whatsapp.com/DtBHiLWbKmZI0bzRcr1ylh
┈┈┈┈┈┈┈┈┈┈┈┈
*ᗪᗩᖇKᔕ⟿ꪶ͢𝑴☁️ꫂ ᵉᵈᶦᶻ ᴹᵒᵒⁿᶜˡᵒᵘᵈˢ*
⟿ https://chat.whatsapp.com/DwG4609s1cV3ebPHk570or
┈┈┈┈┈┈┈┈┈┈┈┈
*ᘖᔦ𐋅 ᔕ🎭⟿ꪶ͢𝑴☁️ꫂ ᵉᵈᶦᶻ ᴹᵒᵒⁿᶜˡᵒᵘᵈˢ*
⟿ https://chat.whatsapp.com/CRMhpnhmdRGBK6mKHULGmZ
┈┈┈┈┈┈┈┈┈┈┈┈
*𝓣𝓸𝔁𝓲𝓬𝓞⟿ꪶ͢𝑴☁️ꫂ ᵉᵈᶦᶻ ᴹᵒᵒⁿᶜˡᵒᵘᵈˢ*
⟿ https://chat.whatsapp.com/Kdkny2wpPgm5Mk3uHSeyGH
┈┈┈┈┈┈┈┈┈┈┈┈
*✨ƬΣӨGӨПIΛ✨*
⟿ https://chat.whatsapp.com/CPKHbFZo9ZH7VJUukf6Pww
┈┈┈┈┈┈┈┈┈┈┈┈
*🔱ꪶ͢≋🌀𝕍𝕒𝕝𝕙𝕒𝕝𝕝𝕒🌀ꪶ͢≋🔱*
⟿ https://chat.whatsapp.com/B6j6BuG1fKZByqDnChcWks
┈┈┈┈┈┈┈┈┈┈┈┈
*รקค๓ ꪶ͢𝑴☁️ꫂ*
⟿ https://chat.whatsapp.com/FwdI46Bh1xkIQws3ZBLAlc
┈┈┈┈┈┈┈┈┈┈┈┈
*รקค๓ 𝙸𝙸  ꪶ͢𝑴☁️ꫂ*
⟿ https://chat.whatsapp.com/KbJm21VKu1RDWTIanx5XcL
┈┈┈┈┈┈┈┈┈┈┈┈
*ꪶ Assistenza⟿ꪶ͢𝑴☁️ꫂ ᵉᵈᶦᶻ ᴹᵒᵒⁿᶜˡᵒᵘᵈˢ ꫂ* *_metodi sban_*
⟿ https://chat.whatsapp.com/IzsHQpQDZD7LJ96bZbt3tp
┈┈┈┈┈┈┈┈┈┈┈┈
 ✧──[ *Gruppo Ufficiale* ]──✧
*𝑴𝒐𝒐𝒏𝑪𝒍𝒐𝒖𝒅𝒔⇝ ꪶ͢𝑴☁️ꫂ ᵉᵈᶦᶻ ²⁰²³*
⟿ https://chat.whatsapp.com/JgshFc8KChtAai6ZfbI9QZ
`);
};

handler.help = ['support'];
handler.tags = ['main'];
handler.command = ['grupos', 'gp'];

export default handler;
